These are textures that were made for the Remakequake project, now defunct.

They were painted by various team members including ijed, Gb and a couple by OTP.

They were designed to compliment and expand upon the original id1 texture sets.

Free to use as you see fit, no responsability is taken for anything.

